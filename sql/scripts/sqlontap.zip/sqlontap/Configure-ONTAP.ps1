#Requires -Version 7.0
#Requires -Module AWS.Tools.FSX,AWS.Tools.secretsmanager
[CmdletBinding()]
param(

    [Parameter(Mandatory=$true)]
    [string]$AdminSecret,

    [Parameter(Mandatory=$true)]
    [string]$SQLVMName,

    [Parameter(Mandatory=$true)]
    [string]$datalunsize,

    [Parameter(Mandatory=$true)]
    [string]$loglunsize,

    [Parameter(Mandatory=$true)]
    [string]$Stackname,

    [Parameter(Mandatory=$true)]
    [string]$volume,

    [Parameter(Mandatory=$true)]
    [string]$IGROUP
)
Start-Transcript -Path C:\cfn\log\configureontap.ps1.txt -Append
$ErrorActionPreference = "Stop"

$AdminUser = ConvertFrom-Json -InputObject (Get-SECSecretValue -SecretId $AdminSecret).SecretString
$username = $AdminUser.username
$password = $AdminUser.password
##Create Volume with ONTAP RestAPI via PowerShell 7.0
$fslist = Get-FSXFileSystem|?{$_.Tags.Key -eq 'aws:cloudformation:stack-name' -and $_.Tags.Value -eq $Stackname}
$MgmtDNS = $fslist.ontapconfiguration.Endpoints.Management.DNSName
$token = Invoke-RestMethod -Headers @{"X-aws-ec2-metadata-token-ttl-seconds" = "21600"} -Method PUT -Uri "http://169.254.169.254/latest/api/token"
$region = (Invoke-WebRequest -Uri "http://169.254.169.254/latest/meta-data/placement/region" -Headers @{"X-aws-ec2-metadata-token" = $token} -ErrorAction Stop -UseBasicParsing).Content
$volsize = [math]::round(($fslist.StorageCapacity)*0.85)
$volsize = $volsize.ToString()+"G"
$volume="SQLCluster01"
$aggregate="aggr1"
$IGROUP='SQLigroup'
$pair = "$($username):$($password)"
$bytes = [System.Text.Encoding]::ASCII.GetBytes($pair)
$base64 = [System.Convert]::ToBase64String($bytes)
#get management IP
$nodeiqn = (Get-InitiatorPort).NodeAddress
function returncert{
    param(
    [Parameter(Mandatory=$true)]
    [string]$region
    )
    $certuri= "https://fsx-aws-certificates.s3.amazonaws.com/bundle-$region.pem"
    Invoke-WebRequest -Uri $certuri -OutFile C:\cfn\cert.pem
    $cert = Import-Certificate -FilePath C:\cfn\cert.pem -CertStoreLocation Cert:\LocalMachine\Root
    return Get-ChildItem -Path Cert:\LocalMachine\Root|?{$_.Subject -like $cert.Subject}

}

function callrestapi{
    param(
    [Parameter(Mandatory=$true)]
    [string]$MgmtDNS,
    [Parameter(Mandatory=$true)]
    [string]$uri,
    [Parameter(Mandatory=$true)]
    [string]$region,
    [Parameter(Mandatory=$true)]
    [Hashtable]$parambody,
    [Parameter(Mandatory=$true)]
    [string]$creds
    )
    try{
        $restcert = returncert -region $region
        $resturi = "https://$MgmtDNS/api/$uri"
        $JsonBody = $Body | ConvertTo-Json
        $Params = @{
            "URI"     = "$resturi"
            "Method"  = "POST"
            "Headers" = @{"Authorization" = "Basic $creds"}
            "Body" =  "$JsonBody"
            "ContentType" = "application/json"
        }
        Invoke-RestMethod @Params -Certificate $restcert
    }catch{
        $_ | Write-AWSLaunchWizardException
    }
}
#Start ONTAP configuration
$VolUriDynamicPart='private/cli/volume'
<#$Body = @{
    "volume"  = "$volume"
    "vserver" = "$SQLVMName"
    "aggregate" = "$aggregate"
    "size" = "$volsize"
}
callrestapi -MgmtDNS $MgmtDNS -uri $VolUriDynamicPart -region $region -parambody $Body -creds $base64

Start-Sleep 5#>
##modify volumes
$URI=@"
https://$($MgmtDNS)/api/$($VolUriDynamicPart)?vserver=$($SQLVMName)&volume=$($volume)
"@
$Body = @{
    "fractional-reserve" = "0"
     "space-mgmt-try-first"= "snap_delete"
}

$JsonBody = $Body | ConvertTo-Json
$Params = @{
    "URI"     = "$URI"
    "Method"  = "PATCH"
    "Headers" = @{"Authorization" = "Basic $base64"}
    "Body" =  "$JsonBody"
    "ContentType" = "application/json"
}
try{
    $restcert = returncert -region $region
    Invoke-RestMethod @Params -Certificate $restcert
}catch{
    Write-Output "Volume modification failed"
    #$_ | Write-AWSLaunchWizardException
}
Start-Sleep 5
##create igroup
$IGUriDynamicPart='private/cli/igroup'
$URI = "https://$MgmtDNS/api/$IGUriDynamicPart"
$Body = @{
    "igroup"  = "$IGROUP"
    "vserver" = "$SQLVMName"
    "ostype" = "windows"
     "protocol" = "iscsi"
     "initiator"= @("$nodeiqn")
}
callrestapi -MgmtDNS $MgmtDNS -uri $IGUriDynamicPart -region $region -parambody $Body -creds $base64
Start-Sleep 5
##create data lun
$lunUriDynamicPart='private/cli/lun'
$URI = "https://$MgmtDNS/api/$lunUriDynamicPart"
$LUN = 'sqldata'
$DSIZE = $datalunsize+"G"
$Body = @{
    "vserver" = "$SQLVMName"
    "volume" = "$volume"
    "ostype" = "windows_2008"
    "lun" = "$LUN"
    "size"= "$DSIZE"
}
callrestapi -MgmtDNS $MgmtDNS -uri $lunUriDynamicPart -region $region -parambody $Body -creds $base64

Start-Sleep 5
##mapping data lun
$lunmapsUriDynamicPart = 'protocols/san/lun-maps'
$URI = "https://$MgmtDNS/api/$lunmapsUriDynamicPart"
$volume_PATH = "/vol/$volume/$LUN"
$Body = @{
    "svm" = @{"name" = "$SQLVMName"}
    "lun" = @{"name" = "$volume_PATH"}
    "igroup" = @{"name" = "$IGROUP"}
}
callrestapi -MgmtDNS $MgmtDNS -uri $lunmapsUriDynamicPart -region $region -parambody $Body -creds $base64

##create log lun
$lunUriDynamicPart='private/cli/lun'
$URI = "https://$MgmtDNS/api/$lunUriDynamicPart"
$LUN = 'sqllog'
$LSIZE = $loglunsize+"G"
$Body = @{
    "vserver" = "$SQLVMName"
    "volume" = "$volume"
    "ostype" = "windows_2008"
    "lun" = "$LUN"
    "size"= "$LSIZE"
}
callrestapi -MgmtDNS $MgmtDNS -uri $lunUriDynamicPart -region $region -parambody $Body -creds $base64

Start-Sleep 5
##mapping log lun
$lunmapsUriDynamicPart = 'protocols/san/lun-maps'
$volume_PATH = "/vol/$volume/$LUN"
$Body = @{
    "svm" = @{"name" = "$SQLVMName"}
    "lun" = @{"name" = "$volume_PATH"}
    "igroup" = @{"name" = "$IGROUP"}
}
callrestapi -MgmtDNS $MgmtDNS -uri $lunmapsUriDynamicPart -region $region -parambody $Body -creds $base64

##create quorum lun
$lunUriDynamicPart='private/cli/lun'
$URI = "https://$MgmtDNS/api/$lunUriDynamicPart"
$LUN = 'quorum'
$Body = @{
    "vserver" = "$SQLVMName"
    "volume" = "$volume"
    "ostype" = "windows_2008"
    "lun" = "$LUN"
    "size"= "1G"
}
callrestapi -MgmtDNS $MgmtDNS -uri $lunUriDynamicPart -region $region -parambody $Body -creds $base64

Start-Sleep 5
##mapping quorum lun
$lunmapsUriDynamicPart = 'protocols/san/lun-maps'
$URI = "https://$MgmtDNS/api/$lunmapsUriDynamicPart"
$volume_PATH = "/vol/$volume/$LUN"
$Body = @{
    "svm" = @{"name" = "$SQLVMName"}
    "lun" = @{"name" = "$volume_PATH"}
    "igroup" = @{"name" = "$IGROUP"}
}
callrestapi -MgmtDNS $MgmtDNS -uri $lunmapsUriDynamicPart -region $region -parambody $Body -creds $base64

